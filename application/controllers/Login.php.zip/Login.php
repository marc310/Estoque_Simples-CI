<?php
if (!defined('BASEPATH'))
exit('No direct script access allowed');
 
class Login extends CI_Controller{
    
    function __construct()
    {
        parent::__construct();
    }

    function index() 
    {

        // VALIDATION RULES
        $this->load->library('form_validation');
        $this->form_validation->set_rules('nomeusuario', 'Nomeusuario', 'required');
        $this->form_validation->set_rules('senha', 'Senha', 'required');
        $this->form_validation->set_error_delimiters('<p class="error">', '</p>');


        // MODELO USUARIO
        $this->load->model('Usuario_model', 'usuario');
        $query = $this->usuario->validate();

        if ($this->form_validation->run() == FALSE) 
        {
            $this->load->view('login/entrar');
        } 
        else 
        {
            if ($query) 
            { // VERIFICA LOGIN E SENHA
                $data = array(
                    'nomeusuario' => $this->input->post('nomeusuario'),
                    'logged' => true
                );
                $this->session->set_userdata($data);
                redirect('dashboard/index');
            } 
            else 
            {
                redirect($this->index());
            }
        }
    }
    #
    public function process(){
        // Load the model
        $this->load->model('usuario_model');
        // Validate the user can login
        $result = $this->usuario_model->validar();
        // Now we verify the result
        if(! $result){
            // If user did not validate, then show them login page again
            $this->index();
        }else{
            // If user did validate, 
            // Send them to members area
            redirect('dashboard/index');
        }        
    }
    #
    #
    #
}
